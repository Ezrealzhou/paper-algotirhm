#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <vector>
#include <iomanip>
#include <ctime>
using namespace std;

#define INF 65535//�ޱ�ʱ��Ȩֵ
#define MAX_VERTEX_NUM 200//��󶥵���

int p1[MAX_VERTEX_NUM][MAX_VERTEX_NUM][MAX_VERTEX_NUM];
int CountLines(char *filename)
{
    ifstream ReadFile;
    int n=0;
    string tmp;
    ReadFile.open(filename,ios::in);//ios::in ��ʾ��ֻ���ķ�ʽ��ȡ�ļ�
    if(ReadFile.fail())//�ļ���ʧ��:����0
    {
        return 0;
    }
    else//�ļ�����
    {
        while(getline(ReadFile,tmp,'\n'))
        {
            n++;
        }
        ReadFile.close();
        return n;
    }
}
string ReadLine(char *filename,int line)
{
    int lines,i=0;
    string temp;
    fstream file;
    file.open(filename,ios::in);
    lines=CountLines(filename);
    if(file.fail())
    {
        cout<<"Error: file is not exist";
    }
    while(getline(file,temp)&&i<line-1)
    {
        i++;
    }
    file.close();
    return temp;
}
vector<string> splitString(const string& s)
{
    vector<string> ans;
    int len = s.length();
    if (len == 0) return ans;
    for (int i = 0; i < len;){
        int pos = s.find(' ', i);
        if (pos != string::npos){
            if (pos == i){//������������Ŀո�
                i = pos + 1;
                continue;
            }
            else{
                string strTemp = s.substr(i, pos - i);
                ans.push_back(strTemp);
                i = pos + 1;
            }
        }
        else{
            string strTemp = s.substr(i, len - i);
            ans.push_back(strTemp);
            break;
        }
    }
    return ans;
}

typedef struct MGraph{
    string vexs[200];//������Ϣ
    int arcs[200][200];//�ڽӾ���
    int vexnum, arcnum;//�������ͱ���
}MGraph;

int LocateVex(MGraph G, string u)//���ض���u��ͼ�е�λ��
{
    for(int i=0; i<G.vexnum; i++)
        if(G.vexs[i]==u)
            return i;
    return -1;
}

int* Greedy(int A1[][MAX_VERTEX_NUM], int n1, string s[MAX_VERTEX_NUM], int snum, int NF_num, int c[], int C[], int open[]){
    int u, v, w, i, j, k, t, min, min1;
	int cost1[snum][2]; //��һ�д��ÿ��Դ������ҵ�����С���ۣ��ڶ��д�last VM�㡣
	int *y;
	bool final[MAX_VERTEX_NUM];
    y = new int[10];
	for(u=0; u<snum; u++)
        cost1[u][0]=0;
    //FLOYD����A1[][]

    for(u=0; u<n1; u++)
        for(v=0; v<n1; v++)
            for(w=0; w<n1; w++)
                if(A1[v][u] < INF && A1[u][w] < INF && A1[v][u]+A1[u][w] < A1[v][w])
                {
                    //����D
                    A1[v][w]=A1[v][u]+A1[u][w];

                }
    for(u=0; u<n1; u++)
        for(v=0; v<n1; v++)
            if(u==v)
                A1[u][v]=INF;

    for(u=0; u<snum; u++){
        k=u;
        t=1;
        for(i=0; i<n1; i++)
            final[i]=false;
        final[u]=true;//u�㲢��S��
        while(t<=NF_num){
            min=INF;
            for(i=snum; i<n1; i++){
                if(!final[i] && min>A1[k][i] && c[i]>=C[t]){
                    min = A1[k][i];
                    j=i;
                }
            }
            k=j;
            cost1[u][0]+=open[k]+min;
            final[k]=true;
            t++;
        }
        if(t>NF_num)
            cost1[u][1]=k;
    }
    min1=INF;
    for(i=0; i<snum; i++)
        if(min1>cost1[i][0]){
            min1=cost1[i][0];
            k=cost1[i][1];
        }
    y[0] = k;
    y[1] = min1;
    return y;
}

int Steiner(int A2[][MAX_VERTEX_NUM],string s2[MAX_VERTEX_NUM],int node,int n2,int t,int p[][MAX_VERTEX_NUM][MAX_VERTEX_NUM]){	//t��ʾprimeҪ�õ��ĵ�ĸ���
	int u,v,w,i,j,k,m,l,cost2=0;
	int min, minid;
    int B[MAX_VERTEX_NUM][MAX_VERTEX_NUM];	//�洢���������һ��NF�ĵ������Ŀ�ĵ���ɵ���ȫͼ���ľ���
    string c1[MAX_VERTEX_NUM][MAX_VERTEX_NUM],c2[MAX_VERTEX_NUM][MAX_VERTEX_NUM],c3[MAX_VERTEX_NUM][MAX_VERTEX_NUM];
    int f[MAX_VERTEX_NUM], b[MAX_VERTEX_NUM][2];

	//floyd ���¾���A2[][]����¼�������������·��
    for(v=0; v<n2; v++)
        for(w=0; w<n2; w++){
            for(u=0; u<n2; u++)
                p[v][w][u]=-1;
            if(A2[v][w] < INF)
            {
                p[v][w][0]=v;
                p[v][w][1]=w;
            }
        }
    for(u=0; u<n2; u++)
        for(v=0; v<n2; v++)
            for(w=0; w<n2; w++)
                if(A2[v][u] < INF && A2[u][w] < INF && A2[v][u]+A2[u][w] < A2[v][w])
                {
                    //����D
                    A2[v][w]=A2[v][u]+A2[u][w];
                    //����p����v��w��·���Ǵ�v��u���ٴ�u��w������·��
                    for(i=0; i<n2; i++)
                    {
                        if(p[v][u][i]!=-1)
                            p[v][w][i]=p[v][u][i];
                        else
                            break;
                    }
                    for(j=1; j<n2; j++)//ע�⣺����j��1��ʼ�����Ǵ�0��ʼ����Ϊ��v��u��·�����һ��������u, ����u��w��·����һ��������u��ֻ���ӡuһ�μ��ɡ�
                    {
                        if(p[u][w][j]!=-1)
                            p[v][w][i++]=p[u][w][j];
                        else
                            break;
                    }

                }

    //ȡ��ͼ�еıع���node������Ŀ�ĵ�, �����ȫͼ
    k=node;
    B[0][0]=A2[k][k];
    for(i=0;i<t-1;i++){
    	B[0][i+1]=A2[k][i+n2-t+1];
    	B[i+1][0]=A2[i+n2-t+1][k];
    }
    for(i=1;i<t;i++)
    	for(j=1;j<t;j++)
    		B[i][j]=A2[i+n2-t][j+n2-t];

	int lowcost[MAX_VERTEX_NUM];
	int mst[MAX_VERTEX_NUM];
	int e[t][2];

	for(i = 1; i < t; i++)
	{
		lowcost[i] = B[0][i];
		mst[i] = 0;
	}
	mst[0] = 0;
	for(i = 1; i < t; i++)
	{
		min = INF;
		minid = 0;
		for(j = 1; j < t; j++)
		{
			if (lowcost[j] < min && lowcost[j] != 0)
			{
				min = lowcost[j];
				minid = j;
			}
		}
		e[i-1][0]=mst[minid];
		e[i-1][1]=minid;

		lowcost[minid] = 0;
		for(j = 1; j < t; j++)
		{
			if(B[minid][j] < lowcost[j])
			{
				lowcost[j] = B[minid][j];
				mst[j] = minid;
			}
		}
	}

	// ����e[][]�洢prim�ҵ��ı�(��ű�ʾ)��s2[e[i][j]]��ʾ��Ӧ�ĵ�s,b,c...
	k=node;
	for(i=0;i<t-1;i++)
		for(j=0;j<2;j++)
			if(e[i][j]!=0)
				e[i][j]+=n2-t;
			else
				e[i][j]=k;

	for(i=0;i<t-1;i++){
		k=0;
		for(j=0;j<n2;j++){
			if(p[e[i][0]][e[i][1]][j]!=-1)
				c1[i][k++]=s2[p[e[i][0]][e[i][1]][j]];
			else
				break;
		}
		f[i]=k;
	}

	//f[]��ÿһ�еĶ�����Ŀ��c1[][]�� ÿ��·���еĵ�

    l=0;
	for(i=0;i<t-1;i++)
		for(j=0;j<f[i]-1;j++){
			c2[l][0]=c1[i][j];
			c2[l][1]=c1[i][j+1];
			l++;
		}
	for(i=0;i<l;i++)
		for(j=i+1;j<l;j++)
			if((c2[i][0]==c2[j][0]&&c2[i][1]==c2[j][1])||(c2[i][0]==c2[j][1]&&c2[i][1]==c2[j][0]))
				c2[j][0]="v123";
	k=0;
	for(i=0;i<l;i++)
		if(c2[i][0]!="v123"){
			c3[k][0]=c2[i][0];
			c3[k][1]=c2[i][1];
			k++;
		}
    /*
	//c3[][]��ڶ������ҵ��Ĵ������еı�
	cout<<"�ڶ������ҵ��ı��У�"<<endl;
	for(i=0;i<k;i++){
		for(j=0;j<2;j++)
			cout<<c3[i][j]<<" ";
		cout<<endl;
	}
	//����ҵ��� ��
    */
	for(i=0;i<k;i++)
		for(j=0;j<2;j++)
			for(l=0;l<n2;l++)
				if(s2[l]==c3[i][j])
					b[i][j]=l;
	//��c3[][]�еĵ�ת��Ϊ�õ��Ӧ�ı��
	for(i=0;i<k;i++)
		cost2+=A2[b[i][0]][b[i][1]];
	return cost2;
}


int main()
{
    int i, j, m, n, k, u, v, w, NF_num, source_num, destination_num;
    int lineNum;
    std::vector<string> ans;
    string a;
    int cost=0, cost2;
    int *y;
    int p[MAX_VERTEX_NUM][MAX_VERTEX_NUM];//���·������p
    int D[MAX_VERTEX_NUM];//��̾�������D
    string f[MAX_VERTEX_NUM];//���NF
    string S[MAX_VERTEX_NUM], Des[MAX_VERTEX_NUM];	//	���Դ���Ŀ�ĵ�
	int C[MAX_VERTEX_NUM];		//��ÿ��NF���������
	int c[MAX_VERTEX_NUM], c1[MAX_VERTEX_NUM];		//��ÿ���������������
	int open[MAX_VERTEX_NUM];
	int A1[MAX_VERTEX_NUM][MAX_VERTEX_NUM], A2[MAX_VERTEX_NUM][MAX_VERTEX_NUM];
	string s1[MAX_VERTEX_NUM], s2[MAX_VERTEX_NUM];	//s1[]���һ�����õ��ĵ㣨�����V����Ŀ�ĵ�������е㣩 ��s2[]��ڶ����ֵĵ㣨����Steiner����
	int times=50;
    MGraph g;
    char filename[]="C:\\Users\\Administrator\\Desktop\\DataSet\\input\\FatTree_SFC=7.txt";

    lineNum = CountLines(filename);

    a = ReadLine(filename,1);
    ans = splitString(a);
    g.vexnum = atoi(ans[0].c_str());
    g.arcnum = atoi(ans[1].c_str());
    a = ReadLine(filename,2);
    ans = splitString(a);
    for(i=0; i<g.vexnum; i++)
        g.vexs[i] = ans[i];
    for(i=0; i<g.vexnum; i++)
        for(j=0; j<g.vexnum; j++)
            g.arcs[i][j]=INF;
    for(i=3; i<g.arcnum+3; i++){
        a = ReadLine(filename,i);
        ans = splitString(a);
        for(k=0; k<g.arcnum; k++){
            u=LocateVex(g, ans[0]);
            v=LocateVex(g, ans[1]);
            w = atoi(ans[2].c_str());
            g.arcs[u][v] = w;
            g.arcs[v][u] = w;
        }
    }
    a = ReadLine(filename,g.arcnum+3);
    NF_num = atoi(a.c_str());
    a = ReadLine(filename,g.arcnum+4);
    ans = splitString(a);
    source_num = atoi(ans[0].c_str());
    destination_num = atoi(ans[1].c_str());
    a = ReadLine(filename,g.arcnum+5);
    ans = splitString(a);
    for(i=0; i<source_num; i++)
        S[i] = ans[i];
    a = ReadLine(filename,g.arcnum+6);
    ans = splitString(a);
    for(i=0; i<destination_num; i++)
        Des[i] = ans[i];
    cout<<endl;
    clock_t startTime=clock();

    for(k=0; k<times; k++){
        srand((unsigned)time(NULL));
        for(i=1; i<=NF_num; i++)
            C[i]=rand()%6+5;
        srand((unsigned)time(NULL));
        for(i=0; i<g.vexnum; i++)
            c[i]=rand()%10+40;
        srand((unsigned)time(NULL));
        for(i=0; i<g.vexnum; i++){
            if(g.vexnum > 100)
                open[i]=rand()%10+95;
            else
                open[i]=rand()%10+45;
        }
        s1[0]='V';
        for(i=1; i<=g.vexnum-destination_num; i++)
            s1[i]=g.vexs[i-1];
          //��һ�����õ��ľ���A1��ֻȡԴ���vm����ɵĲ���
        for(i=0; i<g.vexnum-destination_num; i++)
            for(j=0; j<g.vexnum-destination_num; j++)
                A1[i][j]=g.arcs[i][j];
        y = Greedy(A1, g.vexnum-destination_num, g.vexs, source_num, NF_num, c, C, open);

        //�ڶ������õ��ľ���A2
        for(i=source_num; i<g.vexnum; i++)
            s2[i-source_num]=g.vexs[i];
        for(i=source_num; i<g.vexnum; i++)
            for(j=source_num; j<g.vexnum; j++)
                A2[i-source_num][j-source_num]=g.arcs[i][j];
        for(i=0; i<g.vexnum-source_num; i++)
            for(j=0; j<g.vexnum-source_num; j++)
                if(i == j)	A2[i][j]=0;
        cost2 = Steiner(A2, s2, y[0]-source_num, g.vexnum-source_num, destination_num+1, p1);
        cost += y[1]+cost2;
        cout<<"The "<<k+1<<"th cost is "<<y[1]+cost2<<endl;
    }
    cost=cost/times;
    cout<<"The total cost is: "<<cost<<endl;
    clock_t endTime=clock();
    cout<<"The run time is:"<<endTime-startTime<<"ms"<<endl;
  	return 0;
}
