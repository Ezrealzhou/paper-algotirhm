#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <vector>
#include <iomanip>
#include <ctime>
using namespace std;

#define INF 65535//�ޱ�ʱ��Ȩֵ
#define MAX_VERTEX_NUM 200//��󶥵���
int p[MAX_VERTEX_NUM][MAX_VERTEX_NUM][MAX_VERTEX_NUM];

int CountLines(char *filename)
{
    ifstream ReadFile;
    int n=0;
    string tmp;
    ReadFile.open(filename,ios::in);//ios::in ��ʾ��ֻ���ķ�ʽ��ȡ�ļ�
    if(ReadFile.fail())//�ļ���ʧ��:����0
    {
        return 0;
    }
    else//�ļ�����
    {
        while(getline(ReadFile,tmp,'\n'))
        {
            n++;
        }
        ReadFile.close();
        return n;
    }
}
string ReadLine(char *filename,int line)
{
    int i=0;
    string temp;
    fstream file;
    file.open(filename,ios::in);
    //lines=CountLines(filename);
    if(file.fail())
    {
        cout<<"Error: file is not exist";
    }
    while(getline(file,temp)&&i<line-1)
    {
        i++;
    }
    file.close();
    return temp;
}
vector<string> splitString(const string& s)
{
    vector<string> ans;
    int len = s.length();
    if (len == 0) return ans;
    for (int i = 0; i < len;){
        int pos = s.find(' ', i);
        if (pos != string::npos){
            if (pos == i){//������������Ŀո�
                i = pos + 1;
                continue;
            }
            else{
                string strTemp = s.substr(i, pos - i);
                ans.push_back(strTemp);
                i = pos + 1;
            }
        }
        else{
            string strTemp = s.substr(i, len - i);
            ans.push_back(strTemp);
            break;
        }
    }
    return ans;
}

typedef struct MGraph{
    string vexs[200];//������Ϣ
    int arcs[200][200];//�ڽӾ���
    int vexnum, arcnum;//�������ͱ���
}MGraph;

int LocateVex(MGraph G, string u)//���ض���u��ͼ�е�λ��
{
    for(int i=0; i<G.vexnum; i++)
        if(G.vexs[i]==u)
            return i;
    return -1;
}

int* SteinerTree(int A1[][MAX_VERTEX_NUM], int n1, int snum, int t, int p[][MAX_VERTEX_NUM][MAX_VERTEX_NUM]){
    int i, j, k, u, v, w, m, n;
    int cost1=INF;
    int *y;
    int STsum[MAX_VERTEX_NUM];  //��ÿ��ST�Ĵ���
    int min, min1, minid;
	int B[MAX_VERTEX_NUM][MAX_VERTEX_NUM];
    y = new int[2];

    for(i=0; i<snum; i++)
        STsum[i] = 0;
    //floyd ���¾���g[][]����¼�������������·��
    for(v=0; v<n1; v++)
        for(w=0; w<n1; w++)
        {
            for(u=0; u<n1; u++)
                p[v][w][u]=-1;
            if(A1[v][w] < INF)
            {
                p[v][w][0]=v;
                p[v][w][1]=w;
            }
        }
    for(u=0; u<n1; u++)
        for(v=0; v<n1; v++)
            for(w=0; w<n1; w++)
                if(A1[v][u] < INF && A1[u][w] < INF && A1[v][u]+A1[u][w] < A1[v][w])
                {
                    //����D
                    A1[v][w]=A1[v][u]+A1[u][w];
                    for(i=0; i<n1; i++)
                    {
                        if(p[v][u][i]!=-1)
                            p[v][w][i]=p[v][u][i];
                        else
                            break;
                    }
                    for(j=1; j<n1; j++)//ע�⣺����j��1��ʼ�����Ǵ�0��ʼ����Ϊ��v��u��·�����һ��������u, ����u��w��·����һ��������u��ֻ���ӡuһ�μ��ɡ�
                    {
                        if(p[u][w][j]!=-1)
                            p[v][w][i++]=p[u][w][j];
                        else
                            break;
                    }
                }
    //�Խ����ϵ�ֵΪ0
    for(i=0; i<n1; i++)
        for(j=0; j<n1; j++)
            if(i == j)  A1[i][j]=INF;

    //���ȣ�������Դ�ڵ�ֱ���һ��ST,ȡ���д�����С��ST��
    for(k=0; k<snum; k++)    //ȡ��һ��Դ�������Ŀ�ĵ������ȫͼ
    {
        B[0][0]=A1[k][k];
        for(i=1,m=n1-t+1; m<n1; i++,m++)
        {
            B[0][i] = A1[k][m];
            B[i][0] = A1[m][k];
        }
        for(i=1,m=n1-t+1; m<n1; i++,m++)
            for(j=1,n=n1-t+1; n<n1; j++,n++)
            {
                B[i][j] = A1[m][n];
                B[j][i] = A1[n][m];
            }
        int lowcost[MAX_VERTEX_NUM];/* mst[i]��¼��Ӧlowcost[i]����㣬��mst[i]=0ʱ��ʾ���i���������� */
        int mst[MAX_VERTEX_NUM];
        for(i = 1; i < t; i++)
        {
            lowcost[i] = B[0][i];
            mst[i] = 0;
        }
        mst[0] = 0;
        for(i = 1; i < t; i++)
        {
            min = INF;
            minid = 0;
            for(j = 1; j < t; j++)
            {
                if (lowcost[j] < min && lowcost[j] != 0)
                {
                    min = lowcost[j];
                    minid = j;
                }
            }
            STsum[k] += min;
            lowcost[minid] = 0;
            for(j = 1; j < t; j++)
            {
                if(B[minid][j] < lowcost[j])
                {
                    lowcost[j] = B[minid][j];
                    mst[j] = minid;
                }
            }
        }
    }
    for(i=0; i<snum; i++)
    {
        if(cost1>STsum[i])
        {
            cost1=STsum[i];
            k=i;
        }
    }
    y[0] = cost1;
    y[1] = k;
    return y;
}
int* Deployment(int A2[][MAX_VERTEX_NUM], int n2, int c[MAX_VERTEX_NUM], int C[MAX_VERTEX_NUM], int NF_num, int k){
    int i, j, l=1, min;
    int cost2=0;
    bool final[MAX_VERTEX_NUM];
    int *z;
    z = new int[MAX_VERTEX_NUM];

    for(i=0; i<n2; i++)
        final[i]=false;
    final[k]=true;
    while(l<=NF_num)
    {
        min=INF;
        for(i=0; i<n2; i++)
        {
            if(!final[i] && min>A2[k][i] && c[i]>=C[l])
            {
                min = A2[k][i];
                j=i;
            }
        }
        c[j] -= C[l];
        cost2 += C[l]+min*2;
        final[j]=true;
        l++;
    }
    z[0] = cost2;
    for(i=0; i<n2; i++)
        z[i+1] = c[i];
    return z;
}
int main()
{
    int i, j, k, u, v, w, x, NF_num, source_num, destination_num;
    int lineNum;
    string a;
    std::vector<string> ans;
    int total_cost=0;
    int *y, *z;

    string S[MAX_VERTEX_NUM], Des[MAX_VERTEX_NUM];	//	���Դ���Ŀ�ĵ�
	int C[MAX_VERTEX_NUM], c[MAX_VERTEX_NUM];		//��ÿ��NF���������,��ÿ���������������
	int VNF[30];
    bool visit[30];
	int chainNum;
    MGraph g;

    char filename[]="C:\\Users\\Administrator\\Desktop\\�ಥ·��\\multi-source service chain embedding\\online\\DataSet\\input\\Iris_r=75.txt";

    lineNum = CountLines(filename);
    a = ReadLine(filename,1);
    ans = splitString(a);
    g.vexnum = atoi(ans[0].c_str());
    g.arcnum = atoi(ans[1].c_str());
    a = ReadLine(filename,2);
    ans = splitString(a);
    for(i=0; i<g.vexnum; i++)
        g.vexs[i] = ans[i];
    for(i=0; i<g.vexnum; i++)
        for(j=0; j<g.vexnum; j++)
            g.arcs[i][j]=INF;
    for(i=3; i<g.arcnum+3; i++){
        a = ReadLine(filename,i);
        ans = splitString(a);
        for(k=0; k<g.arcnum; k++){
            u=LocateVex(g, ans[0]);
            v=LocateVex(g, ans[1]);
            w = atoi(ans[2].c_str());
            g.arcs[u][v] = w;
            g.arcs[v][u] = w;
        }
    }
    a = ReadLine(filename,g.arcnum+3);
    ans = splitString(a);
    source_num = atoi(ans[0].c_str());
    destination_num = atoi(ans[1].c_str());
    a = ReadLine(filename,g.arcnum+4);
    ans = splitString(a);
    for(i=0; i<source_num; i++)
        S[i] = ans[i];
    a = ReadLine(filename,g.arcnum+5);
    ans = splitString(a);
    for(i=0; i<destination_num; i++)
        Des[i] = ans[i];
    a = ReadLine(filename,g.arcnum+6);
    chainNum = atoi(a.c_str());
    cout<<endl;
    clock_t startTime=clock();

    srand((unsigned)time(NULL));
	for(i=0; i<30; i++){
        VNF[i]=rand()%100+100;
        visit[i]=false;
	}
    srand((unsigned)time(NULL));
    for(i=0; i<g.vexnum; i++)
        c[i]=rand()%8000+4000;

    for(x=0; x<chainNum; x++)
    {
        NF_num = rand()%5+3;
        srand((unsigned)time(NULL));
        for(i=1; i<=NF_num; ){
            j=rand()%30;
            if(!visit[j]){
                C[i]=VNF[j];
                visit[j]=true;
                i++;
            }
        }
        for(i=0; i<30; i++){
            visit[i]=false;
        }

        y = SteinerTree(g.arcs, g.vexnum, source_num, destination_num+1, p);

        z = Deployment(g.arcs, g.vexnum-destination_num, c, C, NF_num, y[1]);
        for(i=0; i<g.vexnum-destination_num; i++)
            c[i] = z[i+1];

        cout<<"The "<<x+1<<"th chain cost is "<<y[0]+z[0]<<endl;
        total_cost += y[0]+z[0];
    }
    cout<<"The accumulate cost is: "<<total_cost<<endl;
    clock_t endTime=clock();
    cout<<"The run time is:"<<endTime-startTime<<"ms"<<endl;
  	return 0;
}
