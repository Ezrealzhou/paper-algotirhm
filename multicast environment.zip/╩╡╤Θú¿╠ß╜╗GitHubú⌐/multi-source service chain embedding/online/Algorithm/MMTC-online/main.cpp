#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <vector>
#include <iomanip>
#include <ctime>
using namespace std;

#define INF 65535
#define MAX_VERTEX_NUM 200
int p[MAX_VERTEX_NUM][MAX_VERTEX_NUM][MAX_VERTEX_NUM];

int CountLines(char *filename)
{
    ifstream ReadFile;
    int n=0;
    string tmp;
    ReadFile.open(filename,ios::in);//ios::in ��ʾ��ֻ���ķ�ʽ��ȡ�ļ�
    if(ReadFile.fail())//�ļ���ʧ��:����0
    {
        return 0;
    }
    else//�ļ�����
    {
        while(getline(ReadFile,tmp,'\n'))
        {
            n++;
        }
        ReadFile.close();
        return n;
    }
}
string ReadLine(char *filename,int line)
{
    int lines,i=0;
    string temp;
    fstream file;
    file.open(filename,ios::in);
    lines=CountLines(filename);
    if(file.fail())
    {
        cout<<"Error: file is not exist";
    }
    while(getline(file,temp)&&i<line-1)
    {
        i++;
    }
    file.close();
    return temp;
}
vector<string> splitString(const string& s)
{
    vector<string> ans;
    int len = s.length();
    if (len == 0) return ans;
    for (int i = 0; i < len;){
        int pos = s.find(' ', i);
        if (pos != string::npos){
            if (pos == i){//������������Ŀո�
                i = pos + 1;
                continue;
            }
            else{
                string strTemp = s.substr(i, pos - i);
                ans.push_back(strTemp);
                i = pos + 1;
            }
        }
        else{
            string strTemp = s.substr(i, len - i);
            ans.push_back(strTemp);
            break;
        }
    }
    return ans;
}

typedef struct MGraph{
    string vexs[200];
    int arcs[200][200];
    int vexnum, arcnum;
}MGraph;

int LocateVex(MGraph G, string u)
{
    for(int i=0; i<G.vexnum; i++)
        if(G.vexs[i]==u)
            return i;
    return -1;
}

int* ShortestPath_DIJ(int A1[][MAX_VERTEX_NUM], int n1, string s1[MAX_VERTEX_NUM], int v0, int p[][MAX_VERTEX_NUM], int D[], int NF_num, int c[], int C[])
{
    int u, v, w, i, j, k, t, r, min, min1;
	int cost1=0;
	int *y;
    int f[MAX_VERTEX_NUM];	/**< which node deployed which VNF */
    bool final[MAX_VERTEX_NUM];
    y = new int[MAX_VERTEX_NUM];
    for(v=0; v<n1; v++)
    {
        final[v]=false;
        D[v]=A1[v0][v];
        for(w=0; w<n1; w++)
            p[v][w]=-1;
        if(D[v]<INF)
        {
            p[v][0]=v0; /**< the first node passed from v0 to v */
            p[v][1]=v; /**< the second node passed from v0 to v */
        }
    }

    D[v0]=0;    /**< the value v0->v0 is 0 */
    final[v0]=true;     /**< add v0 to set S */

    for(i=0; i<n1; i++)
    	f[i]=0;

	for(i=1; i<n1; i++){
   		min=INF;
       	for(w=0; w<n1; w++)
          	if(!final[w] && D[w]<min){
				v=w;
               	min=D[w];
            }
        final[v]=true;  /**< add v to set S */

       	for(w=0; w<n1; w++){	 /**< according v,fresh the value from other nodes(not in S) to v0 */
        	if(!final[w] && min<INF && A1[v][w]<INF && (min+A1[v][w]<=D[w])){
               	D[w]=min+A1[v][w];
               	for(j=0; j<n1; j++){
                    p[w][j]=p[v][j];
                    if(p[w][j]==-1)
                    {
                       	p[w][j]=w;
                       	break;
                    }
                }
            }
       	}
       	min1=INF;
       	for(u=0; u<n1; u++)
			if(final[u] && p[v][u]!=-1 && A1[u][v]<min1){
				t = u;
				min1 = A1[u][v];
			}
        while(t!=v0 &&  f[t]==0){
            r = t;
            min1=INF;
            for(u=0; u<n1; u++)
                if(final[u] && p[r][u]!=-1 && A1[u][r]<min1){
                    t = u;
                    min1 = A1[u][r];
                }
        }
       	k=f[t];
        /**< t is the previous node of v that may deploying VNF */
        while(k < NF_num && c[v] > C[k+1])
        {
            c[v] -= C[k+1];
            cost1 += C[k+1];
            k++;
        }
        f[v]=k;
		if(k == NF_num)
			break;
    }

    if(k<NF_num){
        cout<<"The chain cannot be deployed."<<endl;
        cout<<endl;
        y[0]=-1;
        for(i=0; i<n1; i++)
            y[i+1] = c[i];
    }
    else{
        cout<<"The shortest path in first part is: ";
        for(i=0; i<n1; i++){
            if(f[i] == NF_num){
                u=i;
            }
        }

        /**< the sum of weight in the path */
        for(j=0; j<n1; j++)
            if(p[u][j]>-1){
                if(p[u][j+1]>-1)
                    cost1 += A1[p[u][j]][p[u][j+1]];
                cout<<s1[p[u][j]]<<" ";
            }
        cout<<endl;
        for(i=0; i<n1; i++){
            if(p[u][i]>-1 && f[p[u][i]]>0){
                cout<<"node "<<s1[p[u][i]]<<" deployed VNF:";
                for(j=f[p[u][i-1]]+1; j<=f[p[u][i]]; j++){
                    cout<<j<<" ";
                }
                cout<<endl;
            }
        }
        y[0] = u;
        y[1] = cost1;
        for(i=0; i<n1; i++)
            y[i+2] = c[i];
    }
    return y;
}

int Steiner(int A2[][MAX_VERTEX_NUM],string s2[MAX_VERTEX_NUM],string node,int n2,int t,int p[][MAX_VERTEX_NUM][MAX_VERTEX_NUM]){	//t��ʾprimeҪ�õ��ĵ�ĸ���
	int u,v,w,i,j,k,l,cost2=0;
	int min, minid;
    int B[MAX_VERTEX_NUM][MAX_VERTEX_NUM];	/**< composed by the node(deploy the last VNF) and all the destinations */
    string X1[MAX_VERTEX_NUM][MAX_VERTEX_NUM],X2[MAX_VERTEX_NUM][MAX_VERTEX_NUM],X3[MAX_VERTEX_NUM][MAX_VERTEX_NUM];
    int f[MAX_VERTEX_NUM], b[MAX_VERTEX_NUM][2];

	/**< fresh A2[][] using Floyd, record the minimal distance between each two nodes */
    for(v=0; v<n2; v++)
        for(w=0; w<n2; w++){
            for(u=0; u<n2; u++)
                p[v][w][u]=-1;
            if(A2[v][w] < INF)
            {
                p[v][w][0]=v;
                p[v][w][1]=w;
            }
        }
    for(u=0; u<n2; u++)
        for(v=0; v<n2; v++)
            for(w=0; w<n2; w++)
                if(A2[v][u] < INF && A2[u][w] < INF && A2[v][u]+A2[u][w] < A2[v][w])
                {
                    A2[v][w]=A2[v][u]+A2[u][w];
                    for(i=0; i<n2; i++)
                    {
                        if(p[v][u][i]!=-1)
                            p[v][w][i]=p[v][u][i];
                        else
                            break;
                    }

                    /**< notice: j begin from 1, because from v->u,u->w,just need print u once */
                    for(j=1; j<n2; j++)
                    {
                        if(p[u][w][j]!=-1)
                            p[v][w][i++]=p[u][w][j];
                        else
                            break;
                    }

                }

    /**< get the last VNF node and all destinations, compose a complete graph */
    for(i=0; i<n2; i++)
		if(s2[i]==node)
			k=i;
    B[0][0]=A2[k][k];
    for(i=0;i<t-1;i++){
    	B[0][i+1]=A2[k][i+n2-t+1];
    	B[i+1][0]=A2[i+n2-t+1][k];
    }
    for(i=1;i<t;i++)
    	for(j=1;j<t;j++)
    		B[i][j]=A2[i+n2-t][j+n2-t];
    /*
    cout<<"t="<<t<<endl;
    for(i=0;i<t;i++){
        for(j=0;j<t;j++)
            cout<<setw(5)<<B[i][j];
        cout<<endl;
    }
    */

	int lowcost[MAX_VERTEX_NUM];
	int mst[MAX_VERTEX_NUM];
	int e[t][2];

	for(i = 1; i < t; i++)
	{
		lowcost[i] = B[0][i];
		mst[i] = 0;
	}
	mst[0] = 0;
	for(i = 1; i < t; i++)
	{
		min = INF;
		minid = 0;
		for(j = 1; j < t; j++)
		{
			if (lowcost[j] < min && lowcost[j] != 0)
			{
				min = lowcost[j];
				minid = j;
			}
		}
		e[i-1][0]=mst[minid];
		e[i-1][1]=minid;

		lowcost[minid] = 0;
		for(j = 1; j < t; j++)
		{
			if(B[minid][j] < lowcost[j])
			{
				lowcost[j] = B[minid][j];
				mst[j] = minid;
			}
		}
	}

	/**< e[][] save the found links(use number represent), using s2[e[i][j]] to get the correspond nodes: s,b,c...*/
	for(i=0; i<n2; i++)
		if(s2[i]==node)
			k=i;
	for(i=0;i<t-1;i++)
		for(j=0;j<2;j++)
			if(e[i][j]!=0)
				e[i][j]+=n2-t;
			else
				e[i][j]=k;

    /**< f[] save how many nodes of a row, X1[][] save the nodes in each path */
	for(i=0;i<t-1;i++){
		k=0;
		for(j=0;j<n2;j++){
			if(p[e[i][0]][e[i][1]][j]!=-1)
				X1[i][k++]=s2[p[e[i][0]][e[i][1]][j]];
			else
				break;
		}
		f[i]=k;
	}

    l=0;
	for(i=0;i<t-1;i++)
		for(j=0;j<f[i]-1;j++){
			X2[l][0]=X1[i][j];
			X2[l][1]=X1[i][j+1];
			l++;
		}
	for(i=0;i<l;i++)
		for(j=i+1;j<l;j++)
			if((X2[i][0]==X2[j][0]&&X2[i][1]==X2[j][1])||(X2[i][0]==X2[j][1]&&X2[i][1]==X2[j][0]))
				X2[j][0]="v123";
	k=0;
	for(i=0;i<l;i++)
		if(X2[i][0]!="v123"){
			X3[k][0]=X2[i][0];
			X3[k][1]=X2[i][1];
			k++;
		}

    /**< Print the found links of the second part. */
    /*
    cout<<"The links found in second part are:"<<endl;
	for(i=0;i<k;i++){
		for(j=0;j<2;j++)
			cout<<X3[i][j]<<" ";
		cout<<endl;
	}
	*/
	for(i=0;i<k;i++)
		for(j=0;j<2;j++)
			for(l=0;l<n2;l++)
				if(s2[l]==X3[i][j])
					b[i][j]=l;

	for(i=0;i<k;i++)
		cost2+=A2[b[i][0]][b[i][1]];
	return cost2;
}


int main()
{
    int i, j, k, u, v, w, NF_num, source_num, destination_num;
    int lineNum;
    std::vector<string> ans;
    int cost=0, cost2;
	string node, a;
    int *y;
    int p1[MAX_VERTEX_NUM][MAX_VERTEX_NUM];
    int D[MAX_VERTEX_NUM];
    string S[MAX_VERTEX_NUM], Des[MAX_VERTEX_NUM];
	int C[MAX_VERTEX_NUM];		/**< save the required computing resource of each VNF */
	int c[MAX_VERTEX_NUM], c1[MAX_VERTEX_NUM];		/**< save the available computing resource of each VM */
	int A1[MAX_VERTEX_NUM][MAX_VERTEX_NUM], A2[MAX_VERTEX_NUM][MAX_VERTEX_NUM];

	/**< s1[] save the first part nodes(including super-source V and all the nodes besides destinations),
	s2[] save the second part nodes(including all the nodes besides sources)*/
	string s1[MAX_VERTEX_NUM], s2[MAX_VERTEX_NUM];
	int VNF[30];    /**< assume there are 30 type different VNF */
	bool visit[30]; /**< mark a VNF whether be selected */
	int chainNum; /**< the number of arrived service chains*/
    MGraph g;

    char filename[]="C:\\Users\\Administrator\\Desktop\\�ಥ·��\\multi-source service chain embedding\\online\\DataSet\\input\\Iris_r=100.txt";

    lineNum = CountLines(filename);
    a = ReadLine(filename,1);
    ans = splitString(a);
    g.vexnum = atoi(ans[0].c_str());
    g.arcnum = atoi(ans[1].c_str());
    a = ReadLine(filename,2);
    ans = splitString(a);
    for(i=0; i<g.vexnum; i++)
        g.vexs[i] = ans[i];
    for(i=0; i<g.vexnum; i++)
        for(j=0; j<g.vexnum; j++)
            g.arcs[i][j]=INF;
    for(i=3; i<g.arcnum+3; i++){
        a = ReadLine(filename,i);
        ans = splitString(a);
        for(k=0; k<g.arcnum; k++){
            u=LocateVex(g, ans[0]);
            v=LocateVex(g, ans[1]);
            w = atoi(ans[2].c_str());
            g.arcs[u][v] = w;
            g.arcs[v][u] = w;
        }
    }
    a = ReadLine(filename,g.arcnum+3);
    ans = splitString(a);
    source_num = atoi(ans[0].c_str());
    destination_num = atoi(ans[1].c_str());
    a = ReadLine(filename,g.arcnum+4);
    ans = splitString(a);
    for(i=0; i<source_num; i++)
        S[i] = ans[i];
    a = ReadLine(filename,g.arcnum+5);
    ans = splitString(a);
    for(i=0; i<destination_num; i++)
        Des[i] = ans[i];
    a = ReadLine(filename,g.arcnum+6);
    chainNum = atoi(a.c_str());
    cout<<endl;
    clock_t startTime=clock();

    srand((unsigned)time(NULL));
	for(i=0; i<30; i++){
        VNF[i]=rand()%100+100;
        visit[i]=false;
	}
	srand((unsigned)time(NULL));
    for(i=source_num; i<g.vexnum-destination_num; i++){
        c[i]=rand()%8000+4000;
    }

     /**< the first part matrix A1[][] */
    s1[0]='V';
    for(i=1; i<=g.vexnum-destination_num; i++)
        s1[i]=g.vexs[i-1];
    /**< set the available resource of super-source as 0 */
    for(i=g.vexnum-destination_num; i>0; i--){
        c1[i]=c[i-1];
    }
    c1[0]=0;
    A1[0][0]=INF;
    for(i=1; i<=source_num; i++){
        A1[0][i]=0;
        A1[i][0]=INF;
    }
    for(i=source_num+1; i<=g.vexnum-destination_num; i++){
        A1[0][i]=INF;
        A1[i][0]=INF;
    }
    for(i=0; i<g.vexnum-destination_num; i++)
        for(j=0; j<g.vexnum-destination_num; j++)
            A1[i+1][j+1]=g.arcs[i][j];

     /**< the second part */
    for(i=source_num; i<g.vexnum; i++)
        s2[i-source_num]=g.vexs[i];
    for(i=source_num; i<g.vexnum; i++)
        for(j=source_num; j<g.vexnum; j++)
            A2[i-source_num][j-source_num]=g.arcs[i][j];
    for(i=0; i<g.vexnum-source_num; i++)
        for(j=0; j<g.vexnum-source_num; j++)
            if(i == j)
                A2[i][j]=0;

    srand((unsigned)time(NULL));
    for(k=0; k<chainNum; k++){
        NF_num = rand()%5+3;
        srand((unsigned)time(NULL));
        for(i=1; i<=NF_num; ){
            j=rand()%30;
            if(!visit[j]){
                C[i]=VNF[j];
                visit[j]=true;
                i++;
            }
        }
        for(i=0; i<30; i++){
            visit[i]=false;
        }

        y = ShortestPath_DIJ(A1, g.vexnum-destination_num+1, s1, 0, p1, D, NF_num, c1, C);

        if(y[0] != -1){
            for(i=0; i<g.vexnum-destination_num+1; i++)
                c1[i] = y[i+2];
            node = g.vexs[y[0]-1];

            cost2=Steiner(A2,s2,node,g.vexnum-source_num,destination_num+1,p);

            cost+=y[1]+cost2;
            cout<<"The "<<k+1<<" th cost is: "<<y[1]+cost2<<endl;
            cout<<endl;
        }
        else{
            continue;
        }
    }
    clock_t endTime=clock();
    cout<<"The accumulate cost is: "<<cost<<endl;
    cout<<"The run time is:"<<endTime-startTime<<"ms"<<endl;
  	return 0;
}
